from django import template
register = template.Library()

@register.filter
def firstelement(value):   
    try:
        return [item[0] for item in value]
    except Exception:
        return value
@register.filter
def getfiltrable(value):
    try:
        return [item[0] for item in value if item[2]]
    except Exception as e:
        print(e)
        return value