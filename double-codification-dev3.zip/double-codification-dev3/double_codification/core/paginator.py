from rest_framework.pagination import PageNumberPagination
from django.conf import settings

class CustomPagination(PageNumberPagination):
    page_size = 10  # Nombre d'éléments par page (modifiable)
    page_size_query_param = "page_size"
    max_page_size = 100  # Pour limiter la taille max

    def get_next_link(self):
        url = super().get_next_link()
        if url and settings.USE_X_FORWARDED_HOST:
            return url.replace("http://localhost:8000", settings.DEFAULT_DOMAIN)
        return url

    def get_previous_link(self):
        url = super().get_previous_link()
        if url and settings.USE_X_FORWARDED_HOST:
            return url.replace("http://localhost:8000", settings.DEFAULT_DOMAIN)
        return url
