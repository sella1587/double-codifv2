from rest_framework import serializers
from .models import ConsolidatedObjects, ObjectsFromCao
from .models import OwnerCodeDetails, OwnerCodeProperties

class DynamicConsolidatedObjectsSerializer(serializers.ModelSerializer):
    generate_data_config = serializers.SerializerMethodField()
    render_code_client_ouvrage = serializers.SerializerMethodField()
    facteur_choc = serializers.StringRelatedField()
    degre_choc = serializers.StringRelatedField()
    avec_plots = serializers.StringRelatedField()
    avec_carlingage = serializers.StringRelatedField()
    date_traitement_cao = serializers.DateTimeField(format="%Y-%m-%d %H:%M")
    creation_date = serializers.DateTimeField(format="%Y-%m-%d %H:%M")
    date_last_modified = serializers.DateTimeField(format="%Y-%m-%d %H:%M")
    date_last_modified_dc = serializers.DateTimeField(format="%Y-%m-%d %H:%M")

    def __init__(self, *args, **kwargs):
        fields_to_include = kwargs.pop('fields', None)
        super().__init__(*args, **kwargs)

        if fields_to_include:
            allowed = set(fields_to_include)
            existing = set(self.fields)
            for field in existing - allowed:
                self.fields.pop(field)

    class Meta:
        model = ConsolidatedObjects
        fields = '__all__'
        
    def get_generate_data_config(self, obj):        
        return obj.generate_data_config()
    
    def get_render_code_client_ouvrage(self, obj):
        return obj.render_code_client_ouvrage()
    def get_facteur_choc(self, obj):
        return obj.facteur_choc.value if obj.facteur_choc else None

    def get_degre_choc(self, obj):
        return obj.degre_choc.value if obj.degre_choc else None

    def get_avec_plots(self, obj):
        return obj.avec_plots.value if obj.avec_plots else None

    def get_avec_carlingage(self, obj):
        return obj.avec_carlingage.value if obj.avec_carlingage else None


class SerialObjectFromCao(serializers.ModelSerializer):
    facteur_choc = serializers.SerializerMethodField()
    degre_choc = serializers.SerializerMethodField()
    avec_plots = serializers.SerializerMethodField()
    avec_carlingage = serializers.SerializerMethodField()
    date_traitement_cao = serializers.DateTimeField(format="%Y-%m-%d %H:%M")  # Format français
    creation_date = serializers.DateTimeField(format="%Y-%m-%d %H:%M")
    date_last_modified = serializers.DateTimeField(format="%Y-%m-%d %H:%M")
    date_last_modified_dc = serializers.DateTimeField(format="%Y-%m-%d %H:%M")

    def __init__(self, *args, **kwargs):
        fields_to_include = kwargs.pop('fields', None)
        super().__init__(*args, **kwargs)

        if fields_to_include:
            allowed = set(fields_to_include)
            existing = set(self.fields)
            for field in existing - allowed:
                self.fields.pop(field)

    def get_facteur_choc(self, obj):
        return obj.facteur_choc.value if obj.facteur_choc else None

    def get_degre_choc(self, obj):
        return obj.degre_choc.value if obj.degre_choc else None

    def get_avec_plots(self, obj):
        return obj.avec_plots.value if obj.avec_plots else None

    def get_avec_carlingage(self, obj):
        return obj.avec_carlingage.value if obj.avec_carlingage else None

    class Meta:
        model = ObjectsFromCao
        fields = '__all__'




class OwnerCodeDetailsSerializer(serializers.ModelSerializer):
    objconso = serializers.PrimaryKeyRelatedField(queryset=ConsolidatedObjects.objects.all())
    ownercode = serializers.PrimaryKeyRelatedField(queryset=OwnerCodeProperties.objects.all())

    class Meta:
        model = OwnerCodeDetails
        fields = ['objconso', 'ownercode', 'fieldvalue']
