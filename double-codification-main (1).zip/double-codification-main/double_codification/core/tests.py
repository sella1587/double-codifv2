from django.test import TestCase

# Create your tests here.
class FakeTest(TestCase):
    def test_faketest(self):
        self.assertEqual(1,1)

